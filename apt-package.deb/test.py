import subprocess
subprocess.run(["/usr/bin/notify-send", "--icon=info", "Message send VIA python script in package my-custom-package"])